package com.cg.omts.screen.validation;

import java.util.regex.Pattern;

public class ScreenValidation {
	public boolean isValidScreenName(String screenName) {
		String namePattern = "^[A-Za-z][A-Za-z0-9\\s]{2,10}$";
		if (Pattern.matches(namePattern, screenName)) {
			return true;
		}
		return false;

	}

	public boolean isValidRows(Integer rows) {
		if (rows > 0 && rows <= 200) {
			return true;
		}

		return false;
	}

	public boolean isValidColumns(Integer columns) {
		if (columns > 0 && columns <= 200) {
			return true;
		}

		return false;

	}
}
