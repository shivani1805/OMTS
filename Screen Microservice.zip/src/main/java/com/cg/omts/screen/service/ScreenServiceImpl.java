package com.cg.omts.screen.service;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.omts.screen.dao.ScreenDao;
import com.cg.omts.screen.entity.ScreenEntity;
import com.cg.omts.screen.exception.CustomException;
import com.cg.omts.screen.exception.NotFoundException;
import com.cg.omts.screen.validation.ScreenValidation;


@Service
public class ScreenServiceImpl implements ScreenService {
	@Autowired
	ScreenDao screenRepository;
	Logger logger = LoggerFactory.getLogger(ScreenServiceImpl.class);
	String message = "Screen Not Found";
	ScreenValidation validate = new ScreenValidation();

	@Override
	public ScreenEntity addScreen(ScreenEntity screen) {
		if (!validate.isValidScreenName(screen.getScreenName())) {
			throw new CustomException("Invalid Screen Name : Screen name can only contain characters And Digits.");
		} else if (!validate.isValidRows(screen.getRows())) {
			throw new CustomException("Invalid Rows");

		} else if (!validate.isValidColumns(screen.getColumns())) {
			throw new CustomException("Invalid columns");
		} else {

			if (screen.getScreenId()!=null) {
				Optional<ScreenEntity> screenDetail = screenRepository.findById(screen.getScreenId());
				if (screenDetail.isPresent()) {
					logger.error("Could not add Screen as Screen ID was already present");
					throw new CustomException("screen with this ID is already present!");
				} else {

					return screenRepository.save(screen);
				}
			} else {
				return screenRepository.save(screen);
			}
		}
	}

	@Override
	public String deleteScreen(Integer screenId) {
		Optional<ScreenEntity> screen = screenRepository.findById(screenId);
		if (screenId == null) {
			throw new NotFoundException("Please enter a screen ID");
		}
		if (screen.isPresent()) {
			screenRepository.deleteById(screenId);
			return "Screen with ID: '" + screenId + "' deleted successfully";

		} else {
			logger.error(message);
			throw new NotFoundException(String.format("Oops, could not find screen with ID: '%d' ", screenId));
		}

	}

	@Override
	public String editScreen(ScreenEntity screen) {
		if (!validate.isValidScreenName(screen.getScreenName())) {
			throw new CustomException("Invalid Screen Name : Screen name can only contain characters And Digits.");
		} else if (!validate.isValidRows(screen.getRows())) {
			throw new CustomException("Invalid Rows");

		} else if (!validate.isValidColumns(screen.getColumns())) {
			throw new CustomException("Invalid columns");
		} else {
			Integer screenId = screen.getScreenId();
			if (screenRepository.existsById(screenId)) {
				screenRepository.save(screen);
				return "Screen Updated Successfully";
			} else {
				logger.error(message);
				throw new NotFoundException(String.format("Oops, could not find screen with ID:'%d'", screenId));
			}
		}
	}

	@Override
	public ScreenEntity getScreenById(Integer screenId) {
		Optional<ScreenEntity> screen = screenRepository.findById(screenId);
		if (screen.isPresent()) {
			return screen.get();
		}

		else {
			logger.error(message);
			throw new NotFoundException("Could not find screen");
		}
	}

	@Override
	public List<ScreenEntity> getAllScreens() {
		List<ScreenEntity> screenList = screenRepository.findAll();
		if (screenList.isEmpty()) {
			logger.error("No screen could be found");
			throw new NotFoundException("Oops, Could not find any screen");
		} else {

			return screenList;
		}
	}

	@Override
	public List<ScreenEntity> getScreenByTheatreId(Integer theatreId) {
		List<ScreenEntity> screenList = screenRepository.getScreenByTheatreId(theatreId);
		if (screenList.isEmpty()) {
			logger.error("No screen could be found in theatre");
			throw new NotFoundException(
					String.format("Oops , could not find screen in theatre with ID :%d", theatreId));
		} else {
			return screenList;
		}

	}

}
