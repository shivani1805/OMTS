package com.cg.omts.screen.controller;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.omts.screen.dto.MessageDto;
import com.cg.omts.screen.dto.ScreenDto;
import com.cg.omts.screen.dto.ShowDto;
import com.cg.omts.screen.entity.ScreenEntity;
import com.cg.omts.screen.service.ScreenService;


@RestController
@RequestMapping("/screen")
@CrossOrigin("http://localhost:4200")
public class ScreenController {
	@Autowired
	private ScreenService screenService;
	@Autowired
	RestTemplate restTemplate;
	Logger logger = LoggerFactory.getLogger(ScreenController.class);

	@PostMapping("/new")
	public ResponseEntity<ScreenDto> addNewScreen(@RequestBody ScreenEntity screen) {
		//ScreenEntity screenEntity = convertToScreenEntity(screen);
		ScreenEntity screenEntity = screenService.addScreen(screen);
		ScreenDto screenDto = convertToScreenDto(screenEntity);
		ResponseEntity<ScreenDto> response = new ResponseEntity<>(screenDto, HttpStatus.OK);
		logger.info("New Screen Added Successfully");
		return response;

	}

	@GetMapping("/getScreenById/id={screenId}")
	public ResponseEntity<ScreenDto> getScreenById(@PathVariable Integer screenId) {
		ScreenEntity screen = screenService.getScreenById(screenId);
		ScreenDto screenDto = convertToScreenDto(screen);
		ResponseEntity<ScreenDto> response = new ResponseEntity<>(screenDto, HttpStatus.OK);
		logger.info("Details of screen returned successully");
		return response;
	}

	@DeleteMapping("/delete/id={screenId}")
	public ResponseEntity<MessageDto> deleteScreen(@PathVariable Integer screenId) {
		String deleteResult = screenService.deleteScreen(screenId);
		MessageDto message = sendMessage(deleteResult);
		ResponseEntity<MessageDto> response = new ResponseEntity<>(message, HttpStatus.OK);
		logger.info("Screen deleted successfully");
		return response;

	}

	@PutMapping("/update")
	public ResponseEntity<MessageDto> editScreen(@RequestBody ScreenDto screen) {
		ScreenEntity screenEntity = convertToScreenEntity(screen);
		String updateResult = screenService.editScreen(screenEntity);
		MessageDto message = sendMessage(updateResult);
		ResponseEntity<MessageDto> response = new ResponseEntity<>(message, HttpStatus.OK);
		logger.info("Screen Updated Successfully");
		return response;

	}

	@GetMapping("/getAllScreens")
	public ResponseEntity<List<ScreenDto>> getAllScreens() {
		List<ScreenEntity> screenList = screenService.getAllScreens();
		List<ScreenDto> screenDtoList = new ArrayList<>();
		for (ScreenEntity screenEntity : screenList) {
			screenDtoList.add(convertToScreenDto(screenEntity));
		}
		ResponseEntity<List<ScreenDto>> response = new ResponseEntity<>(screenDtoList, HttpStatus.OK);
		logger.info("Screen Details returned sucessfully");
		return response;

	}

	@GetMapping("/getScreenByTheatreId/id={theatreId}")
	public ResponseEntity<List<ScreenDto>> getScreenByTheatreId(@PathVariable Integer theatreId) {
		List<ScreenEntity> screenList = screenService.getScreenByTheatreId(theatreId);
		List<ScreenDto> screenDtoList = new ArrayList<>();
		for (ScreenEntity screenEntity : screenList) {
			screenDtoList.add(convertToScreenDto(screenEntity));
		}
		ResponseEntity<List<ScreenDto>> response = new ResponseEntity<>(screenDtoList, HttpStatus.OK);
		logger.info("Details of Screen returned successfully");
		return response;
	}
	@GetMapping("/getShowByScreenId/id={screenId}")
	public ResponseEntity<List<ShowDto>> getShowByScreenId(@PathVariable Integer screenId){
		String url="http://localhost:1112/show/getShowByScreenId/"+screenId;
		List<ShowDto> showList=restTemplate.getForObject(url, List.class);
		ResponseEntity<List<ShowDto>> response=new ResponseEntity<>(showList,HttpStatus.OK);
		return response;
	}

	public ScreenDto convertToScreenDto(ScreenEntity screenEntity) {
		ScreenDto screen = new ScreenDto();
		screen.setScreenId(screenEntity.getScreenId());
		screen.setScreenName(screenEntity.getScreenName());
		screen.setTheatreId(screenEntity.getTheatreId());
		screen.setRows(screenEntity.getRows());
		screen.setColumns(screenEntity.getColumns());
		return screen;
	}

	public ScreenEntity convertToScreenEntity(ScreenDto screenDto) {
		ScreenEntity screen = new ScreenEntity();
		screen.setScreenId(screenDto.getScreenId());
		screen.setScreenName(screenDto.getScreenName());
		screen.setTheatreId(screenDto.getTheatreId());
		screen.setRows(screenDto.getRows());
		screen.setColumns(screenDto.getColumns());
		return screen;
	}

	public MessageDto sendMessage(String message) {
		MessageDto messageDto = new MessageDto();
		messageDto.setMessage(message);
		return messageDto;
	}
	

}
