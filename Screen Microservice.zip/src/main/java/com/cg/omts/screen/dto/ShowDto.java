package com.cg.omts.screen.dto;

import java.time.LocalDateTime;

public class ShowDto {
	private Integer showId;
	private LocalDateTime showStartTime;
	private LocalDateTime showEndTime;
	private String movieName;
	private Integer noOfSeats;
	private Integer screenId;
	private Integer theatreId;

	public ShowDto() {
		super();
	}

	public ShowDto(Integer showId, LocalDateTime showStartTime, LocalDateTime showEndTime, String movieName,
			Integer noOfSeats, Integer screenId, Integer theatreId) {
		super();
		this.showId = showId;
		this.showStartTime = showStartTime;
		this.showEndTime = showEndTime;
		this.movieName = movieName;
		this.noOfSeats = noOfSeats;
		this.screenId = screenId;
		this.theatreId = theatreId;
	}

	public Integer getShowId() {
		return showId;
	}

	public void setShowId(Integer showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowStartTime() {
		return showStartTime;
	}

	public void setShowStartTime(LocalDateTime showStartTime) {
		this.showStartTime = showStartTime;
	}

	public LocalDateTime getShowEndTime() {
		return showEndTime;
	}

	public void setShowEndTime(LocalDateTime showEndTime) {
		this.showEndTime = showEndTime;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Integer getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(Integer noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public Integer getScreenId() {
		return screenId;
	}

	public void setScreenId(Integer screenId) {
		this.screenId = screenId;
	}

	public Integer getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Integer theatreId) {
		this.theatreId = theatreId;
	}

	@Override
	public String toString() {
		return "showDto [showId=" + showId + ", showStartTime=" + showStartTime + ", showEndTime=" + showEndTime
				+ ", movieName=" + movieName + ", noOfSeats=" + noOfSeats + ", screenId=" + screenId + ", theatreId="
				+ theatreId + "]";
	}
}
