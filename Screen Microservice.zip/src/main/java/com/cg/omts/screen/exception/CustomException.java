package com.cg.omts.screen.exception;

public class CustomException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public CustomException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public CustomException(String msg) {
		super(msg);
	}
}
