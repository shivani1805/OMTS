package com.cg.omts.screen.controller;

import java.sql.SQLException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.cg.omts.screen.exception.CustomException;
import com.cg.omts.screen.dto.MessageDto;
import com.cg.omts.screen.exception.NotFoundException;


@ControllerAdvice
public class ExceptionController {
	@ExceptionHandler({ NotFoundException.class, SQLException.class, NullPointerException.class })
	public ResponseEntity<MessageDto> exception(NotFoundException exception) {
		MessageDto error = new MessageDto(exception.getMessage());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler({ CustomException.class })
	public ResponseEntity<MessageDto> CustomException(CustomException exception) {
		MessageDto error = new MessageDto(exception.getMessage());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	

}
