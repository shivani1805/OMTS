package com.cg.omts.screen.test;

import com.cg.omts.screen.validation.ScreenValidation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

class TestNumberOfRows {
	ScreenValidation validation = new ScreenValidation();
	boolean isValidRows;

	@Test
	void testRowsWithLowerLimit() {
		isValidRows = validation.isValidRows(-1);
		assertFalse(isValidRows);
	}

	@Test
	void testRowsWithUpperLimit() {
		isValidRows = validation.isValidRows(500);
		assertFalse(isValidRows);
	}

	@Test
	void testRowsWithinLimit() {
		isValidRows = validation.isValidRows(150);
		assertTrue(isValidRows);
	}

}
