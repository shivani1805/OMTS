package com.cg.omts.screen.test;

import org.junit.jupiter.api.Test;

import com.cg.omts.screen.validation.ScreenValidation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

class TestScreenName {
	ScreenValidation validation = new ScreenValidation();
	boolean isValidName;

	@Test
	void testScreenNameWithChar() {
		isValidName = validation.isValidScreenName("Audi A");
		assertTrue(isValidName);
	}

	@Test
	void testScreenNameWithDigits() {
		isValidName = validation.isValidScreenName("12");
		assertFalse(isValidName);
	}

	@Test
	void testScreenNameWithCharAndDigit() {
		isValidName = validation.isValidScreenName("Audi 1");
		assertTrue(isValidName);
	}

	@Test
	void testScreenNameWithSpecialChar() {
		isValidName = validation.isValidScreenName("Audi @1");
		assertFalse(isValidName);
	}
}
