package com.cg.omts.screen.test;

import com.cg.omts.screen.validation.ScreenValidation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

class TestNumberOfColumns {
	ScreenValidation validation = new ScreenValidation();
	boolean isValidColumns;

	@Test
	void testColumnsWithLowerLimit() {
		isValidColumns = validation.isValidRows(-1);
		assertFalse(isValidColumns);
	}

	@Test
	void testRowsWithUpperLimit() {
		isValidColumns = validation.isValidRows(500);
		assertFalse(isValidColumns);
	}

	@Test
	void testRowsWithinLimit() {
		isValidColumns = validation.isValidRows(150);
		assertTrue(isValidColumns);
	}

}
