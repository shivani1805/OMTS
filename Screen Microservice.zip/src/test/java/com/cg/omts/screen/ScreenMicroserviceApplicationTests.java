package com.cg.omts.screen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.omts.screen.validation.ScreenValidation;


@SpringBootTest
class ScreenMicroserviceApplicationTests {
	ScreenValidation validation=new ScreenValidation();
	
}
