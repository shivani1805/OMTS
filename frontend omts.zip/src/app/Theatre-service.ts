import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Theatre } from './Theatre';
import { Observable } from 'rxjs';
import { TheatreClass } from './TheatreClass';



@Injectable({
  providedIn: 'root'
})
export class TheatreService
{
  public theatreId:any;
  public tempTheatre:Theatre;
  theatre:TheatreClass;
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
   getTheatreById(theatreId:any):Observable<TheatreClass>
   {
     return this.http.get<TheatreClass>("http://localhost:9091/theatre/viewTheatreById/id="+theatreId,this.httpOptions)
   } 
  addTheatre(theatre:TheatreClass):Observable<TheatreClass>
  {
    return this.http.post<TheatreClass>('http://localhost:9091/theatre/add',JSON.stringify(theatre),this.httpOptions);
  }
  getTheatre():Observable<TheatreClass[]>
  {
   return this.http.get<TheatreClass[]>('http://localhost:9091/theatre/getAllTheatres',this.httpOptions)
    }
deleteTheatre(id:any):Observable<number[]>
  {
    return this.http.delete<number[]>('http://localhost:9091/theatre/deleteTheatre/id='+id,this.httpOptions);
  }
  editTheatre(theatre:TheatreClass):Observable<TheatreClass>
  {
    return this.http.put<TheatreClass>('http://localhost:9091/theatre/update',JSON.stringify(theatre),this.httpOptions)
  }
}
