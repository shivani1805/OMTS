import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewAllTheatreComponent } from './view-all-theatre/view-all-theatre.component';
import { RemoveTheatreComponent } from './remove-theatre/remove-theatre.component';
import { UpdateTheatreComponent } from './update-theatre/update-theatre.component';
import { AddTheatreComponent } from './add-theatre/add-theatre.component';
import { ViewAllScreenComponent } from './view-all-screen/view-all-screen.component';
import { UpdateScreenComponent } from './update-screen/update-screen.component';
import { AddScreenComponent } from './add-screen/add-screen.component';



const routes: Routes = [
  {path:'', redirectTo:'view-all-theatre',pathMatch:'full'},
  {path:'view-all-theatre',component: ViewAllTheatreComponent},
  {path:'remove-theatre',component:RemoveTheatreComponent},
  {path:'update-theatre',component:UpdateTheatreComponent  },
  {path:'add-theatre',component:AddTheatreComponent},
  {path:'view-all-screen',component:ViewAllScreenComponent},
  {path:'update-screen',component:UpdateScreenComponent},
  {path:'add-screen',component:AddScreenComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
