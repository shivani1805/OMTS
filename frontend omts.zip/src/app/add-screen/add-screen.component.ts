import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-screen',
  templateUrl: './add-screen.component.html',
  styleUrls: ['./add-screen.component.css']
})
export class AddScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
