import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ScreenClass } from '../ScreenClass';
import { TheatreService } from '../theatre-service';
import { ScreenService } from '../Screen-service';
import { Router } from '@angular/router';
import { AddScreenComponent } from '../add-screen/add-screen.component';
import { UpdateScreenComponent } from '../update-screen/update-screen.component';
import { TheatreClass } from '../TheatreClass';

@Component({
  selector: 'app-view-all-screen',
  templateUrl: './view-all-screen.component.html',
  styleUrls: ['./view-all-screen.component.css']
})
export class ViewAllScreenComponent implements OnInit {
screen:ScreenClass[];
theatre:TheatreClass[];
  flag1: boolean;
  constructor(private matDialog:MatDialog,private screenSer:ScreenService,private theatreSer:TheatreService,private router:Router) { }

  ngOnInit(): void {
    this.screenSer.getScreens().subscribe(data => this.screen = data);
    this.theatreSer.getTheatre().subscribe(data=>this.theatre=data);
    console.log(this.screen);
    document.getElementById("screenTable").style.display = "block";
  }
  openAddScreenDialog(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.height = '680px';
    dialogConfig.width = '450px';
    const dialogRef = this.matDialog.open(AddScreenComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(data => console.log(data));
  }
  openEditScreenDialog(screenId) {
    this.screenSer.screenId=screenId;
    const editDialogConfig = new MatDialogConfig();
    editDialogConfig.disableClose = true;
    editDialogConfig.autoFocus = true;
    editDialogConfig.height = '680px';
    editDialogConfig.width = '450px';
    const editDialogRef = this.matDialog.open(UpdateScreenComponent, editDialogConfig);
    editDialogRef.afterClosed().subscribe(data => console.log(data));
  }
  removeScreen(screenId) {
    let response = window.confirm("Are you sure you want to delete?");
    console.log(response);
    if (response == true) {
      for (let i = 0; i < this.screen.length; i++) {
        if (this.screen[i].theatreId == screenId) {
          this.screen.splice(i, 1);
          this.theatreSer.deleteTheatre(screenId).subscribe(data => (console.log(data)));
          console.log("Theatre deleted");
          this.flag1 = true;
        }
      }
      window.location.reload();
      window.location.reload();
    }
  }
}
