import { Component } from '@angular/core';
import { TheatreService } from './theatre-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'OMTS';
  flag1:any;
  constructor( private theatreSer:TheatreService)
  {
  }
  ngOnInit()
  {
    this.theatreSer.getTheatre();
    
  }
  run()
  {
    this.flag1==true;
  }
}
