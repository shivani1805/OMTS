import { Component, OnInit } from '@angular/core';
import { ScreenService } from '../Screen-service';
import { DialogBodyComponent } from '../dialog-body/dialog-body.component';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ScreenClass } from '../ScreenClass';
import { TheatreClass } from '../TheatreClass';
import { TheatreService } from '../theatre-service';

@Component({
  selector: 'app-add-screen',
  templateUrl: './add-screen.component.html',
  styleUrls: ['./add-screen.component.css']
})
export class AddScreenComponent implements OnInit {
theatreList:TheatreClass[];
  constructor(private screenSer:ScreenService,public dialogRef:MatDialogRef<AddScreenComponent>,private theatreSer:TheatreService) { }
  newScreen = new FormGroup({
    theatreId:new FormControl(''),
    screenName:new FormControl('',Validators.required),
    rows:new FormControl('',Validators.required),
    columns:new FormControl('',Validators.required)
  });

  ngOnInit(): void {
    this.theatreSer.getTheatre().subscribe(data => this.theatreList = data);
    console.log(this.theatreList);
  }
  close(){
    this.dialogRef.close();
  }
  addScreen(){
    let screenId="";
    let theatreId=this.newScreen.get('theatreId').value;
    let screenName=this.newScreen.get('screenName').value;
    let rows=this.newScreen.get('rows').value;
    let columns=this.newScreen.get('columns').value;
    let tempScreen:ScreenClass=new ScreenClass(screenId,theatreId,screenName,rows,columns);
    this.screenSer.addScreen(tempScreen).subscribe(data=>{console.log(tempScreen)});
    this.dialogRef.close(this.newScreen.value);
  }

}
