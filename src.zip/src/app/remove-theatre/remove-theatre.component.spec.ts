import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveTheatreComponent } from './remove-theatre.component';

describe('RemoveTheatreComponent', () => {
  let component: RemoveTheatreComponent;
  let fixture: ComponentFixture<RemoveTheatreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveTheatreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveTheatreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
