import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroup, FormControl, Validators,FormArray } from '@angular/forms';
import { TheatreService } from '../theatre-service';
import { TheatreClass } from '../TheatreClass';

@Component({
  selector: 'app-dialog-body',
  templateUrl: './dialog-body.component.html',
  styleUrls: ['./dialog-body.component.css']
})
export class DialogBodyComponent implements OnInit {
  message: string;
  theatre: any;

  constructor(private theatreSer:TheatreService,public dialogRef:MatDialogRef<DialogBodyComponent>) { }
  newTheatre = new FormGroup({
    theatreName: new FormControl('', Validators.required),
    theatreCity: new FormControl('', Validators.required),
    managerName: new FormControl('', Validators.required),
    managerContact:new FormControl('',Validators.required),
     movieName: new FormControl(''),
       });
     
     

  ngOnInit(): void {
  }
 
close(){
  this.dialogRef.close();
  }
 saveTheatre(){
  let theatreId="";
  let theatreName=this.newTheatre.get('theatreName').value;
  let theatreCity=this.newTheatre.get('theatreCity').value;
  let managerName=this.newTheatre.get('managerName').value;
  let managerContact=this.newTheatre.get('managerContact').value;
   let movieName1=this.newTheatre.get('movieName1').value;
     let movieList:String[]=[movieName1];
   console.log(movieList);
 let tempTheatre:TheatreClass= new TheatreClass(theatreId,theatreName,theatreCity,movieList,managerName,managerContact);
   this.theatreSer.addTheatre(tempTheatre).subscribe(data=> {
     console.log(tempTheatre);
     
   });      
this.dialogRef.close(this.newTheatre.value);

}
}

