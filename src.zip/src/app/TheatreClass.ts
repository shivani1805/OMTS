export class TheatreClass 
{
    theatreId:any;
    theatreName:any;
    theatreCity:any;
    movieList:String[];
    managerName:any;
    managerContact:any;

constructor(theatreId,theatreName,theatreCity,movieList,managerName,managerContact)
{
    this.theatreId=theatreId;
    this.theatreName=theatreName;
    this.movieList=movieList;
    this.managerName=managerName;
    this.managerContact=managerContact;
    this.theatreCity=theatreCity;
}
}