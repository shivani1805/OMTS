import { Component, OnInit } from '@angular/core';
import { TheatreService } from '../theatre-service';
import { MatDialogRef } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TheatreClass } from '../TheatreClass';
import { Theatre } from '../Theatre';

@Component({
  selector: 'app-update-theatre',
  templateUrl: './update-theatre.component.html',
  styleUrls: ['./update-theatre.component.css']
})
export class UpdateTheatreComponent implements OnInit {
theatre:TheatreClass[];
currentTheatre:Theatre;
  constructor(private theatreSer:TheatreService,public editDialogRef:MatDialogRef<UpdateTheatreComponent>) { }
  updateTheatre = new FormGroup({
    theatreId:new FormControl(''),
    theatreName: new FormControl('', Validators.required),
    theatreCity: new FormControl('', Validators.required),
    managerName: new FormControl('', Validators.required),
    managerContact:new FormControl('',Validators.required),
     movieName: new FormControl(''),
       });
  ngOnInit(): void {
    this.theatreSer.getTheatre().subscribe(data => this.theatre = data);
    console.log(this.theatre);
    this.theatreSer.getTheatreById(this.theatreSer.theatreId).subscribe(data=>this.currentTheatre=data);
    console.log(this.currentTheatre);
  }
editTheatre(){
  let theatreId=this.updateTheatre.get('theatreId').value;
  let theatreName=this.updateTheatre.get('theatreName').value;
  let theatreCity=this.updateTheatre.get('theatreCity').value;
  let managerName=this.updateTheatre.get('managerName').value;
  let managerContact=this.updateTheatre.get('managerContact').value;
  let movieName=this.updateTheatre.get('movieName').value;
  let movieList:String[]=[movieName];
  let tempTheatre:TheatreClass= new TheatreClass(theatreId,theatreName,theatreCity,movieList,managerName,managerContact);
  console.log(tempTheatre);
   this.theatreSer.editTheatre(tempTheatre).subscribe(data=> {
     console.log(tempTheatre);
        });      
this.editDialogRef.close(this.updateTheatre.value);
}
close(){
  this.editDialogRef.close();
  }
}
