import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTheatreComponent } from './add-theatre/add-theatre.component';
import { ViewAllTheatreComponent } from './view-all-theatre/view-all-theatre.component';
import { UpdateTheatreComponent } from './update-theatre/update-theatre.component';
import { RemoveTheatreComponent } from './remove-theatre/remove-theatre.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TheatreService } from './theatre-service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatDialogModule} from '@angular/material/dialog';
import { DialogBodyComponent } from './dialog-body/dialog-body.component';
import { AddScreenComponent } from './add-screen/add-screen.component';
import { UpdateScreenComponent } from './update-screen/update-screen.component';
import { ViewAllScreenComponent } from './view-all-screen/view-all-screen.component';
@NgModule({
  declarations: [
    AppComponent,
    AddTheatreComponent,
    ViewAllTheatreComponent,
    UpdateTheatreComponent,
    RemoveTheatreComponent,
    DialogBodyComponent,
    AddScreenComponent,
    UpdateScreenComponent,
    ViewAllScreenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatDialogModule
  ],
  providers: [TheatreService],
  bootstrap: [AppComponent],
  entryComponents:[DialogBodyComponent,UpdateTheatreComponent,AddScreenComponent,UpdateScreenComponent]
})
export class AppModule { }
