package com.cg.omts.theatre.test;

import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.cg.omts.theatre.validation.TheatreValidation;

public class TestManagerName {
	TheatreValidation validation = new TheatreValidation();

	@Test
	void testManagerNameWithChar() {
		boolean isValidName = validation.isValidManagerName("shivani sharma");
		assertTrue(isValidName);
	}

	@Test
	void testManagerNameWithDigits() {
		boolean isValidName = validation.isValidManagerName("1234");
		assertFalse(isValidName);
	}

	void testManagerNameWithCharAndDigits() {
		boolean isValidName = validation.isValidManagerName("shivani1234");
		assertFalse(isValidName);
	}

	void testManagerNameWithSpecialChar() {
		boolean isValidName = validation.isValidManagerName("Shivani@1");
		assertFalse(isValidName);
	}

}
