package com.cg.omts.theatre.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import com.cg.omts.theatre.validation.TheatreValidation;

public class TestContactNo {
	TheatreValidation validation = new TheatreValidation();

	@Test
	void testContactNoWithCharAndDigits() {
		boolean isContactNoValid = validation.isValidContactNo("9810abdefc");
		assertFalse(isContactNoValid);

	}

	@Test
	void testContactNoWithDigits() {
		boolean isContactNoValid = validation.isValidContactNo("8876543210");
		assertTrue(isContactNoValid);
	}

	@Test
	void testContactNoWithSpecialChar() {
		boolean isContactNoValid = validation.isValidContactNo("8876@!43210");
		assertFalse(isContactNoValid);
	}

	@Test
	void testContactNoWithChar() {
		boolean isContactNoValid = validation.isValidContactNo("abcdefghi");
		assertFalse(isContactNoValid);
	}

	@Test
	void testContactNoUnderLimit() {
		boolean isContactNoValid = validation.isValidCity("987656457");
		assertFalse(isContactNoValid);
	}

	@Test
	public void testContactNoOverLimit() {
		boolean isContactNoValid = validation.isValidCity("98765432109");
		assertFalse(isContactNoValid);
	}

}
