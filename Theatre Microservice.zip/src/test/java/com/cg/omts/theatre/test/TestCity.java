package com.cg.omts.theatre.test;

import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import com.cg.omts.theatre.validation.TheatreValidation;

public class TestCity {
	TheatreValidation validation = new TheatreValidation();

	@Test
	void testCityWithCharAndDigits() {
		boolean isCityValid = validation.isValidCity("Dlf Phase 1");
		assertTrue(isCityValid);
	}

	@Test
	public void testCityWithDigits() {
		boolean isCityValid = validation.isValidCity("1234");
		assertFalse(isCityValid);
	}

	@Test
	public void testCityWithSpecialChar() {
		boolean isCityValid = validation.isValidCity("Dlf Phase@ 1");
		assertFalse(isCityValid);
	}

	@Test
	public void testCityWithChar() {
		boolean isCityValid = validation.isValidCity("Dlf phase");
		assertTrue(isCityValid);
	}

}
