package com.cg.omts.theatre.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import com.cg.omts.theatre.validation.TheatreValidation;

 class TestTheatreName {
	TheatreValidation validation = new TheatreValidation();

	@Test
	void testTheatreNameWithChar() {
		boolean isValidName = validation.isValidTheatreName("shivani sharma");
		assertTrue(isValidName);
	}

	@Test
	void testTheatreNameWithDigits() {
		boolean isValidName = validation.isValidTheatreName("1234");
		assertFalse(isValidName);
	}

	void testTheatreNameWithCharAndDigits() {
		boolean isValidName = validation.isValidTheatreName("shivani1234");
		assertFalse(isValidName);
	}

	void testTheatreNameWithSpecialChar() {
		boolean isValidName = validation.isValidTheatreName("Shivani@1");
		assertFalse(isValidName);
	}

}
