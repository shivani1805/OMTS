package com.cg.omts.theatre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.omts.theatre.validation.TheatreValidation;

@SpringBootTest
class TheatreMicroserviceApplicationTests {
	TheatreValidation validation = new TheatreValidation();

}
