package com.cg.omts.theatre.dto;


import java.util.List;

public class TheatreDto {
	private Integer theatreId;
	private String theatreName;
	private String theatreCity;
	private List<String> movieList;
	private String managerName;
	private String managerContact;

	public TheatreDto() {
		super();
	}

	public TheatreDto(Integer theatreId, String theatreName, String theatreCity, List<String> movieList,
			String managerName, String managerContact) {
		super();
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.theatreCity = theatreCity;
		this.movieList = movieList;
		this.managerName = managerName;
		this.managerContact = managerContact;
	}
	

	public Integer getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Integer theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getTheatreCity() {
		return theatreCity;
	}

	public void setTheatreCity(String theatreCity) {
		this.theatreCity = theatreCity;
	}

	public List<String> getMovieList() {
		return movieList;
	}

	public void setMovieList(List<String> movieList) {
		this.movieList = movieList;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getManagerContact() {
		return managerContact;
	}

	public void setManagerContact(String managerContact) {
		this.managerContact = managerContact;
	}

	@Override
	public String toString() {
		return "TheatreDto [theatreId=" + theatreId + ", theatreName=" + theatreName + ", theatreCity=" + theatreCity
				+ ", movieList=" + movieList + ", managerName=" + managerName + ", managerContact=" + managerContact
				+ "]";
	}

}
