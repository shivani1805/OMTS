package com.cg.omts.theatre.controller;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.cg.omts.theatre.dto.MessageDto;
import com.cg.omts.theatre.dto.MovieDto;
import com.cg.omts.theatre.dto.ScreenDto;
import com.cg.omts.theatre.dto.ShowDto;
import com.cg.omts.theatre.dto.TheatreDto;
import com.cg.omts.theatre.entity.TheatreEntity;
import com.cg.omts.theatre.service.TheatreService;

@RestController
@RequestMapping("/theatre")
@CrossOrigin("http://localhost:4200")
public class TheatreController {
	@Autowired
	TheatreService theatreService;
	@Autowired
	RestTemplate restTemplate;
	Logger logger = LoggerFactory.getLogger(TheatreController.class);

	@PostMapping("/add")
	public ResponseEntity<TheatreDto> addTheatre(@RequestBody TheatreEntity theatre) {
		//TheatreEntity theatreEntity = convertToTheatreEntity(theatre);
		TheatreEntity theatreEntity  = theatreService.addTheatre(theatre);
		TheatreDto theatreDto = convertToTheatreDto(theatreEntity);
		ResponseEntity<TheatreDto> response = new ResponseEntity<>(theatreDto, HttpStatus.OK);
		logger.info("Theatre Added Successfully");
		return response;
	}

	@PutMapping("/update")
	public ResponseEntity<MessageDto> editTheatre(@RequestBody TheatreDto theatre) {
		TheatreEntity theatreEntity = convertToTheatreEntity(theatre);
		String updateResult = theatreService.editTheatre(theatreEntity);
		MessageDto message = sendMessage(updateResult);
		ResponseEntity<MessageDto> response = new ResponseEntity<>(message, HttpStatus.OK);
		logger.info("Theatre Updated Sucessfully");
		return response;
	}

	@GetMapping("/viewTheatreById/id={theatreId}")
	public ResponseEntity<TheatreDto> getTheatreById(@PathVariable Integer theatreId) {
		TheatreEntity theatre = theatreService.getTheatreById(theatreId);
		TheatreDto theatreDto = convertToTheatreDto(theatre);
		ResponseEntity<TheatreDto> response = new ResponseEntity<>(theatreDto, HttpStatus.OK);
		logger.info("Details of theatre returned successfully");
		return response;
	}

	@DeleteMapping("/deleteTheatre/id={theatreId}")
	public ResponseEntity<MessageDto> deleteTheatre(@PathVariable Integer theatreId) {
		String deleteResult = theatreService.deleteTheatre(theatreId);
		MessageDto message = sendMessage(deleteResult);
		ResponseEntity<MessageDto> response = new ResponseEntity<>(message, HttpStatus.OK);
		logger.info("Theatre deleted successfully");
		return response;

	}

	@GetMapping("/viewTheatreByCity/city={city}")
	public ResponseEntity<List<TheatreDto>> getTheatreByCity(@PathVariable String city) {
		List<TheatreEntity> theatreList = theatreService.getTheatreByCity(city);
		List<TheatreDto> theatreDtoList = new ArrayList<>();
		for (TheatreEntity theatreEntity : theatreList) {
			theatreDtoList.add(convertToTheatreDto(theatreEntity));
		}
		ResponseEntity<List<TheatreDto>> response = new ResponseEntity<>(theatreDtoList, HttpStatus.OK);
		logger.info("List of theatres returned successfully");
		return response;

	}

	@GetMapping("/screenByTheatreId/id={theatreId}")
	public ResponseEntity<List<ScreenDto>> getScreenByTheatreId(@PathVariable Integer theatreId) {
		String url = "http://localhost:9092/screen/getScreenByTheatreId/id=" + theatreId;
		List<ScreenDto> screen = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<ScreenDto>> response = new ResponseEntity<>(screen, HttpStatus.OK);
		logger.info("Screens returned successfully");
		return response;
	}

	@GetMapping("/viewAllMovie")
	public ResponseEntity<List<MovieDto>> getAllMovie() {
		String url = "http://localhost:1111/movie/allmovies";
		List<MovieDto> movie = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<MovieDto>> response = new ResponseEntity<>(movie, HttpStatus.OK);
		return response;

	}

	@GetMapping("/searchMovie/movie={movieName}")
	public ResponseEntity<MovieDto> searchMovie(@PathVariable String movieName) {
		String url = "http://localhost:1111/movie/moviebyname/" + movieName;
		MovieDto movieDetail = restTemplate.getForObject(url, MovieDto.class);
		ResponseEntity<MovieDto> response = new ResponseEntity<>(movieDetail, HttpStatus.OK);
		logger.info("Details of movie returned successfully");
		return response;
	}

	@GetMapping("/getAllTheatres")
	public ResponseEntity<List<TheatreDto>> getAllTheatres() {
		List<TheatreEntity> theatreList = theatreService.getAllTheatres();
		List<TheatreDto> theatreDtoList = new ArrayList<>();
		for (TheatreEntity theatreEntity : theatreList) {
			theatreDtoList.add(convertToTheatreDto(theatreEntity));
		}
		ResponseEntity<List<TheatreDto>> response = new ResponseEntity<>(theatreDtoList, HttpStatus.OK);
		logger.info("List of all theatres was returned successfully");
		return response;
	}

	@GetMapping("/viewShowByTheareId/id={theatreId}")
	public ResponseEntity<List<ShowDto>> getShowByTheatreId(@PathVariable Integer theatreId) {
		String url = "http://localhost:1112/show/getShowByTheatreId/" + theatreId;
		List<ShowDto> showList = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<ShowDto>> response = new ResponseEntity<>(showList, HttpStatus.OK);
		logger.info("List of all shows in the theatre returned successfully");
		return response;

	}

	@GetMapping("/viewShowByMovieName/movie={movieName}")
	public ResponseEntity<List<ShowDto>> getShowByMovieName(@PathVariable String movieName) {
		String url = "http://localhost:1112/show/getShowByMovie/" + movieName;
		List<ShowDto> showList = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<ShowDto>> response = new ResponseEntity<>(showList, HttpStatus.OK);
		logger.info("List of all shows for the movie returned successfully");
		return response;
	}

	public TheatreEntity convertToTheatreEntity(TheatreDto theatreDto) {
		TheatreEntity theatre = new TheatreEntity();
		theatre.setTheatreId(theatreDto.getTheatreId());
		theatre.setTheatreName(theatreDto.getTheatreName());
		theatre.setManagerName(theatreDto.getManagerName());
		theatre.setManagerContact(theatreDto.getManagerContact());
		theatre.setMovieList(theatreDto.getMovieList());
		theatre.setTheatreCity(theatreDto.getTheatreCity());
		return theatre;
	}

	public TheatreDto convertToTheatreDto(TheatreEntity theatreEntity) {
		TheatreDto theatre = new TheatreDto();
		theatre.setTheatreId(theatreEntity.getTheatreId());
		theatre.setTheatreName(theatreEntity.getTheatreName());
		theatre.setManagerName(theatreEntity.getManagerName());
		theatre.setManagerContact(theatreEntity.getManagerContact());
		theatre.setMovieList(theatreEntity.getMovieList());
		theatre.setTheatreCity(theatreEntity.getTheatreCity());
		return theatre;
	}

	public MessageDto sendMessage(String message) {
		MessageDto messageDto = new MessageDto();
		messageDto.setMessage(message);
		return messageDto;
	}

}
