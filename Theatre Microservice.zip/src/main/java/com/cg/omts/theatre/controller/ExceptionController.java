package com.cg.omts.theatre.controller;

import java.sql.SQLException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import com.cg.omts.theatre.dto.MessageDto;
import com.cg.omts.theatre.exception.CustomException;
import com.cg.omts.theatre.exception.NotFoundException;

@ControllerAdvice
@RestController
public class ExceptionController {
	@ExceptionHandler({ NotFoundException.class, SQLException.class, NullPointerException.class })
	public ResponseEntity<MessageDto> NotFoundexception(NotFoundException exception) {
		MessageDto error = new MessageDto(exception.getMessage());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler({ CustomException.class })
	public ResponseEntity<MessageDto> CustomException(CustomException exception) {
		MessageDto error = new MessageDto(exception.getMessage());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
