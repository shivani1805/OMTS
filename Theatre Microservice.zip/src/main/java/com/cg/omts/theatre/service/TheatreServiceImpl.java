package com.cg.omts.theatre.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.omts.theatre.dao.TheatreDao;
import com.cg.omts.theatre.entity.TheatreEntity;
import com.cg.omts.theatre.exception.CustomException;
import com.cg.omts.theatre.exception.NotFoundException;
import com.cg.omts.theatre.validation.TheatreValidation;

@Service
public class TheatreServiceImpl implements TheatreService {
	@Autowired
	TheatreDao theatreRepository;
	Logger logger = LoggerFactory.getLogger(TheatreServiceImpl.class);
	TheatreValidation validate = new TheatreValidation();

//Function to add a theatre 
	@Override
	public TheatreEntity addTheatre(TheatreEntity theatre) {

		if (!validate.isValidTheatreName(theatre.getTheatreName())) {
			throw new CustomException("Invalid theatre name");
		} else if (!validate.isValidManagerName(theatre.getManagerName())) {
			throw new CustomException("Invalid manager name");
		} else if (!validate.isValidCity(theatre.getTheatreCity())) {
			throw new CustomException("Invalid city");
		} else if (!validate.isValidContactNo(theatre.getManagerContact())) {
			throw new CustomException("Invalid contact number");
		} else {
			if (theatre.getTheatreId() != null) {
				Optional<TheatreEntity> theatreDetail = theatreRepository.findById(theatre.getTheatreId());
				if (theatreDetail.isPresent()) {
					logger.error("Could not add theatre as theatre ID was already present");
					throw new CustomException("Theatre with this ID is already present!");
				} else {

					return theatreRepository.save(theatre);
				}
			} else {
				return theatreRepository.save(theatre);
			}
		}
	}

//Function  to delete a theatre
	@Override
	public String deleteTheatre(Integer theatreId) {
		Optional<TheatreEntity> theatre = theatreRepository.findById(theatreId);
		if (theatre.isPresent()) {
			theatreRepository.deleteById(theatreId);
			return "Theatre with ID: " + theatreId + " has been deleted successfully";
		} else {
			logger.error("Theatre ID is Invalid");
			throw new NotFoundException(String.format("Theatre ID : '%d' is invalid", theatreId));
		}
	}

//Function to edit or update a theatre
	@Override
	public String editTheatre(TheatreEntity theatre) {

		if (!validate.isValidTheatreName(theatre.getTheatreName())) {
			throw new CustomException("Invalid theatre name");
		} else if (!validate.isValidManagerName(theatre.getManagerName())) {
			throw new CustomException("Invalid manager name");
		} else if (!validate.isValidCity(theatre.getTheatreCity())) {
			throw new CustomException("Invalid city");
		} else if (!validate.isValidContactNo(theatre.getManagerContact())) {

			throw new CustomException("Invalid contact number");
		} else {
			Integer theatreId = theatre.getTheatreId();
			if (theatreRepository.existsById(theatreId)) {
				theatreRepository.save(theatre);
				return "Theatre with ID: '" + theatreId + "' Updated Successfully";
			} else {
				logger.error("Theatre is not present");
				throw new NotFoundException(String.format("Theatre with ID: '%d' is not present", theatreId));
			}
		}

	}

//Function to view a theatre by city
	@Override
	public List<TheatreEntity> getTheatreByCity(String city) {

		if (!validate.isValidCity(city)) {
			throw new CustomException("Invalid city");
		} else {
			List<TheatreEntity> allTheatres = theatreRepository.getTheatreByCity(city);
			if (allTheatres.isEmpty()) {
				logger.error("Could not find theatre in city");
				throw new NotFoundException(String.format("Sorry , could not find theatre in %s", city));
			} else {

				return allTheatres;
			}
		}
	}

//Function to view a theatre by its Id
	@Override
	public TheatreEntity getTheatreById(Integer theatreId) {

		Optional<TheatreEntity> theatreDetail = theatreRepository.findById(theatreId);
		if (theatreDetail.isPresent()) {
			return theatreDetail.get();
		} else {
			logger.error("Theatre is not present");
			throw new NotFoundException(String.format("Sorry, could not find Theatre with ID :'%d'", theatreId));
		}
	}

//Function to view all theatres
	@Override
	public List<TheatreEntity> getAllTheatres() {
		List<TheatreEntity> theatreList = theatreRepository.findAll();
		if (theatreList.isEmpty()) {
			logger.error("List of theatres is not available");
			throw new NotFoundException("List of theatres is not available");
		} else {
			return theatreList;
		}

	}

}
