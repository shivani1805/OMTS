package com.cg.omts.theatre.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.omts.theatre.entity.TheatreEntity;
@Repository
@CrossOrigin("http://localhost:4200")
public interface TheatreDao extends JpaRepository<TheatreEntity, Integer> {
	@Query(value = "Select * from theatre where theatre_city=?1", nativeQuery = true)
	List<TheatreEntity> getTheatreByCity(String city);

}
