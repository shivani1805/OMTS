package com.cg.omts.theatre.validation;

import java.util.regex.Pattern;

public class TheatreValidation {
	public boolean isValidManagerName(String managerName) {
		String namePattern = "^[A-Za-z][A-Za-z\\s]{1,20}$";
		if (Pattern.matches(namePattern, managerName)) {
			return true;
		}
		return false;
	}

	public boolean isValidCity(String city) {
		String cityPattern = "^[A-Za-z][A-Za-z,\\s0-9]{3,20}$";
		if (Pattern.matches(cityPattern, city)) {
			return true;
		}
		return false;
	}

	public boolean isValidContactNo(String contactNo) {
		String contactNoPattern = "^[987][0-9]{9}$";
		if (Pattern.matches(contactNoPattern, contactNo)) {
			return true;
		}
		return false;
	}

	public boolean isValidTheatreName(String theatreName) {
		String theatreNamePattern = "^[A-Za-z][A-Za-z\\s]{2,20}$";
		if (Pattern.matches(theatreNamePattern, theatreName)) {
			return true;
		}
		return false;

	}

}
